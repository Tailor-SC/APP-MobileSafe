package cn.usth.mobilesafe.test;

import java.util.Random;

import android.database.sqlite.SQLiteDatabase;
import android.test.AndroidTestCase;
import cn.usth.mobilesafe.db.BlackNumberOpenHelper;
import cn.usth.mobilesafe.db.dao.BlackNumberDao;

public class BlackNumberTest extends AndroidTestCase{
	
	/**
	 * ���Դ������ݿ�
	 */
	public void createDatebase(){
		
		BlackNumberOpenHelper helper=new BlackNumberOpenHelper(getContext());
		SQLiteDatabase db=helper.getWritableDatabase();
		
	}
	
	public void testAdd(){
		Random random=new Random();
		
		for(int i=0;i<100;i++){
			int num=random.nextInt(100);
			if(i<10){
				BlackNumberDao.getInstance(getContext()).add("13900000000"+num,random.nextInt(3));
			}else{
				BlackNumberDao.getInstance(getContext()).add("139000000"+num,random.nextInt(3));
			}
		}
	}
	
	public void testDelete(){
		BlackNumberDao.getInstance(getContext()).delete("123");;
	} 
	
	public void testUpdate(){
		BlackNumberDao.getInstance(getContext()).update("123", 1);
	}
	
	public void testFindAll(){
		BlackNumberDao.getInstance(getContext()).findAll();
	}

}
