package cn.usth.mobilesafe.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class StreamUtils {
	
	public static String Stream2String(InputStream in) throws IOException{
		
		ByteArrayOutputStream out=new ByteArrayOutputStream();
		
		int len;
		byte[] buffer=new byte[1024];
		while((len=in.read(buffer))!=-1){
			out.write(buffer, 0, len);
		}
		in.close();
		out.close();
		String result=out.toString();
		return result;
		
	}

}
