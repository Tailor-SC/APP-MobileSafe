package cn.usth.mobilesafe.utils;

import java.io.File;
import java.io.IOException;
import java.lang.annotation.Target;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpConnectionParams;
import org.json.JSONException;
import org.json.JSONObject;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import cn.usth.mobilesafe.activity.MainActivity;
import cn.usth.mobilesafe.base.SysConst;
import cn.usth.mobilesafe.domain.VersionEntity;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.text.AlteredCharSequence;
import android.util.Log;
import android.widget.Toast;


public class VersionServerUtils {
	
	private static final int UPDATE_DIALOG = 1;
	private static final int URL_ERROR = 2;
	private static final int IO_ERROR = 3;
	private static final int JSON_ERROR = 4;
	private static final int ENTER_MAIN = 5;
	private static int mVersionCode;
	private static Activity mContext;
	private static VersionEntity mVersionEntity;
	private static ProgressDialog mProgressDialog;
	
	public VersionServerUtils(int mVersionCode, Activity context) {
		super();
		this.mVersionCode = mVersionCode;
		this.mContext = context;
	}
	
	private static Handler mHandler=new Handler(){
		
		public void handleMessage(Message msg){
			switch (msg.what) {
			case UPDATE_DIALOG:
				showUpdateDialog();
				break;
			case URL_ERROR:
				ToastUtils.showToast(mContext, "URL����");
				break;
			case IO_ERROR:
				ToastUtils.showToast(mContext, "IO�쳣");
				enterHome();
				break;
			case JSON_ERROR:
				ToastUtils.showToast(mContext, "JSON�쳣");
				break;
			case ENTER_MAIN:
				enterHome();
				break;

			default:
				break;
			}
		}
		
	};
	
	/**
	 * ��ȡ �������汾��Ϣ
	 */
	public static void getServerVersion(){
		long startTime=System.currentTimeMillis();
		Message msg=Message.obtain();
		mVersionEntity=new VersionEntity();
		
		try {
			
			URL url=new URL(SysConst.IPADDRESS);
			//ctrl+2 l
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(2000);//����ʱ��
			conn.setReadTimeout(2000);//��ȡʱ��
			conn.setRequestMethod("GET");
			conn.connect();
			int responseCode = conn.getResponseCode();//������
			if(responseCode==200){
				Log.e("TAG", "���ӳɹ�");
				String result=StreamUtils.Stream2String(conn.getInputStream());
				
				JSONObject jo=new JSONObject(result);
				mVersionEntity.setVersionCode(jo.getInt("versionCode"));
				Log.e("TAG", ""+mVersionEntity.getVersionCode());
				mVersionEntity.setVersionName(jo.getString("versionName"));
				mVersionEntity.setDesc(jo.getString("desc"));
				mVersionEntity.setApkurl(jo.getString("apkurl"));
				
				//VersionLocalUtils.getVersionCode(context);
				//���̲߳����޸����߳�UI����
				if(mVersionCode<mVersionEntity.getVersionCode()){
					//��������
					System.out.println("��ʼ����");
					
					//��handler
					//showUpdateDialog();
					msg.what=UPDATE_DIALOG;      //ctrl+k
					//Handler��Ϣ�������
				}else{
					msg.what=ENTER_MAIN;
				}
			}else{
				System.out.println("����ʧ��");
			}
		} catch (MalformedURLException e) {
			//���������쳣
			msg.what=URL_ERROR;
			e.printStackTrace();
		} catch (IOException e) {
			msg.what=IO_ERROR;
			e.printStackTrace();
		} catch (JSONException e) {
			msg.what=JSON_ERROR;
			e.printStackTrace();
		}finally{
			long endTime=System.currentTimeMillis();
			long usedTime=endTime-startTime;
			if(usedTime<2000){
				try {
					Thread.sleep(2000-usedTime);//������ʣ��չ�2��
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			mHandler.sendMessage(msg);
		}
	}
	
	private static void enterHome() {
		Intent intent=new Intent(mContext,MainActivity.class);
		mContext.startActivity(intent);
		mContext.finish();
	}

	private static void showUpdateDialog(){
		AlertDialog.Builder builder=new AlertDialog.Builder(mContext);
		builder.setTitle("���°汾"+mVersionEntity.getVersionName());
		builder.setMessage(mVersionEntity.getDesc());
		
	    builder.setPositiveButton("��������", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				System.out.println("��������");
				initProgressDialog();
				downloadApk();
			}
		});
	    
	    builder.setNegativeButton("�ݲ�����", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				
				System.out.println("�ݲ�����");
				dialog.dismiss();
				enterHome();
			}
		});
	    builder.show();
	}

	protected static void initProgressDialog() {
		mProgressDialog=new ProgressDialog(mContext);
		mProgressDialog.setMessage("׼������");
		mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		mProgressDialog.show();
	}

	@SuppressLint("SdCardPath")
	protected static void downloadApk() {
		HttpUtils http=new HttpUtils();
		String target=Environment.getExternalStorageDirectory()+"/mnt/sdcard/MobileSafe.apk";
		http.download(mVersionEntity.getApkurl(), target, new RequestCallBack<File>() {

			@Override
			public void onFailure(HttpException error, String msg) {
				System.out.println("����ʧ��");
			}

			@Override
			public void onSuccess(ResponseInfo<File> responseInfo) {
				System.out.println("���سɹ�");
				mProgressDialog.dismiss();
				installApk();
			}
			
			@Override
			public void onLoading(long total, long current, boolean isUploading) {
				mProgressDialog.setMax((int)total);
				mProgressDialog.setMessage("��������......");
				mProgressDialog.setProgress((int)current);
				super.onLoading(total, current, isUploading);
				
			}
		});
		
			
	}

	protected static void installApk() {
		String fileName=Environment.getExternalStorageDirectory().getAbsolutePath()+"/MobileSafe.apk";
		Intent intent=new Intent(Intent.ACTION_VIEW);
		intent.setDataAndType(Uri.fromFile(new File(fileName)), "application/vnd.android.package-archive");
		mContext.startActivity(intent);
	}
	

}
