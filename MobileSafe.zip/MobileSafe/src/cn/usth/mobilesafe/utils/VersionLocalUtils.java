package cn.usth.mobilesafe.utils;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;

public class VersionLocalUtils {
	
	private int mVersionCode;
	private Activity context;
	
	public VersionLocalUtils(int mVersionCode, Activity context) {
		super();
		this.mVersionCode = mVersionCode;
		this.context = context;
	}
	
	/**
	 * ��ȡ�汾����
	 */
	public static String getVersionName(Context context){
		
		PackageManager pm=context.getPackageManager();
		try {
			PackageInfo info=pm.getPackageInfo(context.getPackageName(), 0);
			return info.versionName;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		
		return "";
	}
	
	/**
	 * ��ȡ�汾��
	 */
	public static int getVersionCode(Context context){
		
		PackageManager pm=context.getPackageManager();
		try {
			PackageInfo info=pm.getPackageInfo(context.getPackageName(), 0);
			return info.versionCode;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return 0;
	}

}
