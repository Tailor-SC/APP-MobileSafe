package cn.usth.mobilesafe.domain;


public class BlackNumberEntity {
	
	private String number;
	private int mode;
	
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public int getMode() {
		return mode;
	}
	public void setMode(int mode) {
		this.mode = mode;
	}
	
	
	

}
