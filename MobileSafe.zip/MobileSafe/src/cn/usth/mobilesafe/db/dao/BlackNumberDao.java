package cn.usth.mobilesafe.db.dao;

import java.util.ArrayList;
import java.util.List;

import cn.usth.mobilesafe.db.BlackNumberOpenHelper;
import cn.usth.mobilesafe.domain.BlackNumberEntity;
import android.R.bool;
import android.R.integer;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class BlackNumberDao {
	
	/**
	 * ����ģʽ
	 */
	private BlackNumberOpenHelper mHelper;
	private static BlackNumberDao instance;

	public BlackNumberDao(Context context){
		
		mHelper = new BlackNumberOpenHelper(context);
		
	}
	
	public static BlackNumberDao getInstance(Context context){
		
		if(instance==null){
			//1,2,3,4,5
			synchronized (BlackNumberDao.class) {
				if(instance==null){
				instance=new BlackNumberDao(context);
				}
			}
		}
		return instance;
	}
	
	/**
	 * ��������
	 * @param number
	 * @param mode
	 */
	public boolean add(String number,int mode){
		boolean isSuccess = false;
		SQLiteDatabase db=mHelper.getWritableDatabase();
		ContentValues values=new ContentValues();
		values.put("number", number);
		values.put("mode", mode);
		long row = db.insert("blacknumber", null, values);
		if (row != -1) {
			isSuccess = true;
		}
		db.close();
		return isSuccess;
	}
	
	/**
	 * ɾ������
	 */
	public int delete(String number){
		SQLiteDatabase db=mHelper.getReadableDatabase();
		//int count = 0;
		int count = db.delete("blacknumber", "number=?", new String[]{number});
		//Cursor cursor = db.rawQuery("delete from blacknumber where number = " + number, null);
//		if (cursor.moveToFirst()) {
//			System.out.print("sssssssssssssssssssssssss");
//			count = 1;
//		}
		db.close();
		return count;
	}
	
	
	/**
	 * �޸�����
	 */
	public void update(String number,int mode){
		SQLiteDatabase db=mHelper.getWritableDatabase();
		ContentValues values=new ContentValues();
		values.put("mode", mode);
		db.update("blacknumber", values, "number=?", new String[]{number});
		db.close();
	}
	
	/**
	 * ��ѯ���еĺ�����
	 */
	public List<BlackNumberEntity> findAll(){
		SQLiteDatabase db=mHelper.getWritableDatabase();
		Cursor cursor=db.query("blacknumber", new String[]{"number","mode"}, null, null, null, null, null);
		List<BlackNumberEntity> mList=new ArrayList<BlackNumberEntity>();
		BlackNumberEntity mBlackNumberEntity=null;
		if(cursor!=null){
//			String[] cols=cursor.getColumnNames();
			while(cursor.moveToNext()){
				mBlackNumberEntity=new BlackNumberEntity();
				mBlackNumberEntity.setNumber(cursor.getString(0));
				mBlackNumberEntity.setMode(cursor.getInt(1));
				mList.add(mBlackNumberEntity);
				mBlackNumberEntity=null;
//				for(String ColumnName:cols){
//					Log.e("TAG", ColumnName+":"+cursor.getString(cursor.getColumnIndex(ColumnName)));
//				}
			}
			cursor.close();
		}
		db.close();
		return mList;
	}

	/**
	 * ��ѯ�����������з�ҳ��ѯ
	 * @param pageIndex
	 * @return
	 */
	public List<BlackNumberEntity> findByPage(int pageIndex){
		SQLiteDatabase db=mHelper.getWritableDatabase();
		Cursor cursor=db.rawQuery("select number,mode from blacknumber limit ?,20", new String[]{pageIndex+""});
		List<BlackNumberEntity> mList=new ArrayList<BlackNumberEntity>();
		BlackNumberEntity mBlackNumberEntity=null;
		if(cursor!=null){
//			String[] cols=cursor.getColumnNames();
			while(cursor.moveToNext()){
				mBlackNumberEntity=new BlackNumberEntity();
				mBlackNumberEntity.setNumber(cursor.getString(0));
				mBlackNumberEntity.setMode(cursor.getInt(1));
				mList.add(mBlackNumberEntity);
				mBlackNumberEntity=null;
//				for(String ColumnName:cols){
//					Log.e("TAG", ColumnName+":"+cursor.getString(cursor.getColumnIndex(ColumnName)));
//				}
			}
			cursor.close();
		}
		db.close();
		return mList;
	}
	
	/**
	 * ��ȡ�����ݿ����������
	 * @return
	 */
	public int getTotalCount(){
		SQLiteDatabase db = mHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("select count(*) from blacknumber", null);
		int total = 0;
		if (cursor.moveToFirst()) {
			total = cursor.getInt(0);
		}
		cursor.close();
		db.close();
		
		return total;
	}
	
	/**
	 * �жϵ绰�����Ƿ����
	 * @param number
	 * @return
	 */
	public boolean isExists(String number) {
		SQLiteDatabase db = mHelper.getReadableDatabase();
		Cursor cursor = db.query("blacknumber", new String[]{"number"}, "number=?", new String[]{number}, null, null, null);
		boolean isExist = false;
		if (cursor.moveToFirst()) {
			isExist = true;
		}
		cursor.close();
		db.close();
		return isExist;
	}
	
	/**
	 * ���ݵ绰������Ѱ�������ķ�ʽ
	 * @param number
	 * @return
	 */
	public int findMode(String number){
		SQLiteDatabase db = mHelper.getReadableDatabase();
		Cursor cursor = db.query("blacknumber", new String[]{"mode"}, "number=?", new String[]{number}, null, null, null);
		int mode = 0;
		if (cursor.moveToFirst()) {
			mode = cursor.getInt(0);
		}
		
		cursor.close();
		db.close();
		return mode;
	}
	
}
