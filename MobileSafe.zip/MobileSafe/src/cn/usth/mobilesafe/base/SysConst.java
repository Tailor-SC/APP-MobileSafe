package cn.usth.mobilesafe.base;

public class SysConst {
	
	public final static String IPADDRESS="http://192.168.1.104:8080/update2014.json";

}
