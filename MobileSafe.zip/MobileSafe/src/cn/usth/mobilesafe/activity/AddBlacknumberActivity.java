package cn.usth.mobilesafe.activity;

import cn.usth.mobilesafe.R;
import cn.usth.mobilesafe.R.id;
import cn.usth.mobilesafe.R.layout;
import cn.usth.mobilesafe.R.menu;
import cn.usth.mobilesafe.db.dao.BlackNumberDao;
import cn.usth.mobilesafe.utils.ToastUtils;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class AddBlacknumberActivity extends Activity implements OnClickListener {
	private CheckBox cbSms;
	private CheckBox cbTel;
	private EditText eText;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_blacknumber);
		
		initView();
		
	}

	private void initView() {
		// TODO Auto-generated method stub
		Button addButton =(Button)findViewById(R.id.add_blacknum_btn);
		addButton.setOnClickListener(this);
		
		cbSms = (CheckBox)findViewById(R.id.cb_blacknumber_sms);
		cbTel = (CheckBox)findViewById(R.id.cb_blacknumber_tel);
		eText = (EditText)findViewById(R.id.et_balcknumber);
		
		RelativeLayout rlLayout = (RelativeLayout)findViewById(R.id.rl_titlebar);
		rlLayout.setBackgroundColor(getResources().getColor(R.color.bright_purple));
		
		ImageView iv_leftbtn = (ImageView)findViewById(R.id.imgv_leftbtn);
		iv_leftbtn.setImageResource(R.drawable.back);
		
		iv_leftbtn.setOnClickListener(this);
		
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.add_blacknum_btn:
			//���Ӻ�����
			//��ȡ���绰���룬����Ϊ��
			//��ȡ����ѡ���״̬
			int mode = 0;
			String number = null;
			if ((!cbSms.isChecked()) && (!cbTel.isChecked())) {
				ToastUtils.showToast(getApplicationContext(), "����Ҫѡ��һ�����ڷ�ʽ");
				return;
			}
			if (cbSms.isChecked() && cbTel.isChecked()) {
				mode = 2;
			}else if (cbTel.isChecked()) {
				mode = 0;
			}else if (cbSms.isChecked()) {
				mode = 1;
			}
			if (eText.getText().toString().equals("")) {
				Toast.makeText(AddBlacknumberActivity.this, "���벻��Ϊ��", Toast.LENGTH_LONG).show();
			}else {
				number = eText.getText().toString();	
				if (BlackNumberDao.getInstance(getApplicationContext()).isExists(number)) {
					ToastUtils.showToast(getApplicationContext(), "�˵绰�������ں������У�");
					return;
				}
				if (BlackNumberDao.getInstance(getApplicationContext()).add(number, mode)) {
					Toast.makeText(AddBlacknumberActivity.this, "���ӳɹ�", Toast.LENGTH_SHORT).show();
				}
			}
			
			break;

		case R.id.imgv_leftbtn:
			finish();
			startActivity(new Intent(AddBlacknumberActivity.this, BlackNumberActivity.class));
			break;
		default:
			break;
		}
	}

	
}
