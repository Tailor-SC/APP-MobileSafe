package cn.usth.mobilesafe.activity;


import cn.usth.mobilesafe.R;
import cn.usth.mobilesafe.utils.VersionLocalUtils;
import cn.usth.mobilesafe.utils.VersionServerUtils;
import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.os.Build;

public class SplashActivity extends Activity {
	
	private TextView tvVersion;
	public VersionServerUtils mVersionServerUtils;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_spalsh);
		//��ʼ���ؼ�
		initView();
        
		//�����汾��
		int mVersionCode=VersionLocalUtils.getVersionCode(this);
		mVersionServerUtils=new VersionServerUtils(mVersionCode, SplashActivity.this);
		
		//���汾��
		checkVersion();
		
	}


	private void initView() {
		tvVersion=(TextView) findViewById(R.id.tv_version);
		tvVersion.setText("��ǰ�汾�ţ�"+VersionLocalUtils.getVersionName(this));
	}

	/**
	 * ���汾��
	 */
	private void checkVersion() {
		//�������粻��ֱ�������߳��в���
		new Thread(){
			@Override
			public void run() {
				//��ȡ�������˵İ汾��Ϣ
				VersionServerUtils.getServerVersion();
			};
		}.start();
	}

}
