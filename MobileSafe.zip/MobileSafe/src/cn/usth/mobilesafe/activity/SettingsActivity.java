package cn.usth.mobilesafe.activity;

public class SettingsActivity {

}
