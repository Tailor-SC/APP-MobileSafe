package cn.usth.mobilesafe.activity.receiver;

import java.lang.reflect.Method;

import com.android.internal.telephony.ITelephony;

import cn.usth.mobilesafe.db.dao.BlackNumberDao;
import android.R.integer;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

public class IncomingCallReceiver extends BroadcastReceiver {

	private TelephonyManager mTm;
	BlackNumberDao mDao;
	@Override
	public void onReceive(Context context, Intent intent) {
		System.out.println("�绰����!");
		
		//�ж��Ƿ��Ǻ������еĺ��룬�����Ų�
		mDao = BlackNumberDao.getInstance(context);
		
		if (intent.getAction().equals(Intent.ACTION_NEW_OUTGOING_CALL)) {
			//System.out.println("----------�绰����!");
		}else {
			System.out.println("----------********�绰����!");
			mTm = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
			
			//���������ȥ�粻ͬ
			mTm.listen(new MyPhoneStateListener(), PhoneStateListener.LISTEN_CALL_STATE);
				
		}
		
	}

	class MyPhoneStateListener extends PhoneStateListener{
		@Override
		public void onCallStateChanged(int state, String incomingNumber) {
			// TODO Auto-generated method stub
			super.onCallStateChanged(state, incomingNumber);
			
			switch (state) {
			case TelephonyManager.CALL_STATE_RINGING:    //��������
				System.out.println("----------��������ǣ� " + incomingNumber);
				int mode = mDao.findMode(incomingNumber);
				System.out.println(incomingNumber + "ģʽ�� " + mode);
				//��ǰ�绰����,�Ҷϵ绰
				if (mDao.isExists(incomingNumber)) {
					System.out.println(incomingNumber + "   : ����");
					//aidl�ļ�
					if (mode == 0 || mode == 2) {
						System.out.println("�Ѿ��Ҷ�!");
						endCall();          //����
					}
				}
				
				break;

			default:
				break;
			}
			
		}
		
	}

	public void endCall() {
		// TODO Auto-generated method stub
		Class clazz;
		try {
			clazz = Class.forName("android.os.ServiceManager");
			Method method = clazz.getMethod("getService", String.class);
			IBinder iBinder = 
					(IBinder) method.invoke(null, Context.TELEPHONY_SERVICE);
			ITelephony iTelephony = ITelephony.Stub.asInterface(iBinder);
			iTelephony.endCall();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
}
