package cn.usth.mobilesafe.activity;

import cn.usth.mobilesafe.R;
import cn.usth.mobilesafe.adapter.MainAdapter;
import cn.usth.mobilesafe.utils.ToastUtils;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;

public class MainActivity extends Activity {

	
	private GridView gvHome;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		initView();

	}

	private void initView() {
		gvHome = (GridView) findViewById(R.id.gv_main);
		gvHome.setAdapter(new MainAdapter(this));
		// ������Ŀ�ĵ���¼�
		gvHome.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				switch (position) {		
				case 0:
					
					break;
				
				case 1:
					startActivity(BlackNumberActivity.class);
					break;

				default:
					break;
				}
			}

		});
	}

	 public void startActivity(Class<?> cls){
	 Intent intent=new Intent(MainActivity.this,cls);
	 startActivity(intent);
	 }


	

}
