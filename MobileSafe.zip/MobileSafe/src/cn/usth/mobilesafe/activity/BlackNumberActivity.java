package cn.usth.mobilesafe.activity;

import java.util.ArrayList;
import java.util.List;

import cn.usth.mobilesafe.R;
import cn.usth.mobilesafe.adapter.BlackNumberAdapter;
import cn.usth.mobilesafe.db.dao.BlackNumberDao;
import cn.usth.mobilesafe.domain.BlackNumberEntity;
import cn.usth.mobilesafe.utils.ToastUtils;
import android.R.bool;
import android.R.integer;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class BlackNumberActivity extends Activity implements OnClickListener{
	
	private List<BlackNumberEntity> mList;
	private ListView lvBlacknumbers;
	private int pageIndex;
	private BlackNumberAdapter mAdapter;
	private boolean isLoading;    //���ر�־
	
	private Handler mHandler = new Handler(){
		
		public void handleMessage(Message msg) {
			if (mAdapter == null) {
				mAdapter = new BlackNumberAdapter(BlackNumberActivity.this,mList);
				lvBlacknumbers.setAdapter(mAdapter);
			}else {
				mAdapter.notifyDataSetChanged();   //���ݼ������˱仯
			}
			isLoading = false;
			pageIndex += mList.size();   //Ϊ��һҳ׼���µ�ҵ����
		};
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_securityphone);
		
		initView();
		initData();
	}

	
	private void initView() {
		
		FrameLayout flHaFrameLayout = (FrameLayout)findViewById(R.id.fl_haveblacknumber);
		FrameLayout flNoFrameLayout = (FrameLayout)findViewById(R.id.fl_noblacknumber);
		
		//û��һ�����ݣ���ʾһ�������ݵĽ���,������ʾ�����ݽ���
		if (BlackNumberDao.getInstance(getApplicationContext()).getTotalCount() == 0) {
			flNoFrameLayout.setVisibility(View.VISIBLE);
			flHaFrameLayout.setVisibility(View.GONE);
		}else {
			flNoFrameLayout.setVisibility(View.GONE);
			flHaFrameLayout.setVisibility(View.VISIBLE);
		}
		
		RelativeLayout rlLayout = (RelativeLayout)findViewById(R.id.rl_titlebar);
		rlLayout.setBackgroundColor(getResources().getColor(R.color.bright_purple));
		
		TextView tv_title = (TextView)findViewById(R.id.tv_title);
		tv_title.setText("ͨѶ��ʿ");
		
		ImageView iv_leftbtn = (ImageView)findViewById(R.id.imgv_leftbtn);
		iv_leftbtn.setImageResource(R.drawable.back);
		
		Button btn_addblacknumber = (Button)findViewById(R.id.btn_addblacknumber);
		btn_addblacknumber.setOnClickListener(this);
		
		iv_leftbtn.setOnClickListener(this);
		
		
		lvBlacknumbers = (ListView) findViewById(R.id.lv_blacknumbers);
		//����listview�����¼�
		lvBlacknumbers.setOnScrollListener(new OnScrollListener() {
			
			//����״̬�ı�
			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				if (scrollState == OnScrollListener.SCROLL_STATE_IDLE) {   //����״̬
					int lastVisiblePosition = lvBlacknumbers.getLastVisiblePosition();
					if (lastVisiblePosition == (mList.size()-1) && !isLoading) {
						//System.out.println("��ͷ�ˣ�");
						isLoading = true;
						
						//���һҳ������ʾ��������ֱ�ӷ��ص���һҳ
						if (mList.size() == BlackNumberDao.getInstance(getApplicationContext()).getTotalCount()) {
							ToastUtils.showToast(getApplicationContext(), "�Ѿ������һҳ��");
							return;
						}
						
						//����������һҳ
						initData();        //������������			
					}
				}
			}
			
			@Override
			public void onScroll(AbsListView view, int firstVisibleItem,
					int visibleItemCount, int totalItemCount) {
				// TODO Auto-generated method stub
				
			}
		});
	}
	
	private void initData() {
		new Thread(){
			//Message msg = Message.obtain();
			//��������
			public void run() {
				//mList = BlackNumberDao.getInstance(getApplicationContext()).findAll();
				//msg.what = 1;
				if (mList == null) {
					//��һ�μ�������
					mList = BlackNumberDao.getInstance(getApplicationContext()).findByPage(pageIndex);
				}else {
					//�ѵ�һ�ε����ݺ�ǰһ�ε����ݵ�����һ��
					mList.addAll(BlackNumberDao.getInstance(getApplicationContext()).findByPage(pageIndex));
				}
				
				mHandler.sendEmptyMessage(0);
				
			};
		}.start();
	}


	@Override
	public void onClick(View v) {
		switch (v.getId()) {
			case R.id.imgv_leftbtn:
				finish();
				break;
				
			case R.id.btn_addblacknumber:
				finish();
				//���Ӻ�����
				startActivity(new Intent(BlackNumberActivity.this, AddBlacknumberActivity.class));
				break;
	
			default:
				break;
		}
	}

}
