package cn.usth.mobilesafe.adapter;

import java.util.List;

import cn.usth.mobilesafe.R;
import cn.usth.mobilesafe.db.dao.BlackNumberDao;
import cn.usth.mobilesafe.domain.BlackNumberEntity;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class BlackNumberAdapter extends BaseAdapter {

	private Context mContext;
	private List<BlackNumberEntity> mList;
	BlackNumberDao mDao;
	
	
	public BlackNumberAdapter(Context mContext, List<BlackNumberEntity> mList) {
		super();
		this.mContext = mContext;
		this.mList = mList;
	}

	@Override
	public int getCount() {
		return mList.size();
	}

	@Override
	public Object getItem(int position) {
		return mList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		
//		View view=null;
		ViewHolder holder=null;

		//��һ�μ���
		if(convertView==null){
			convertView=View.inflate(mContext, R.layout.item_list_blackcontact, null);
		    TextView tvNumber = (TextView) convertView.findViewById(R.id.tv_black_number);
			TextView tvMode = (TextView) convertView.findViewById(R.id.tv_black_mode);
			View vDeleteView = convertView.findViewById(R.id.view_black_delete);
			
			holder = new ViewHolder();
			holder.tvNumber=tvNumber;
			holder.tvMode=tvMode;
			holder.vDelete = vDeleteView;
			convertView.setTag(holder);//��View������VIewHolder�󶨣�view����Я��ViewHolder
		}else{
			holder=(ViewHolder) convertView.getTag();
//			view=convertView;
		}
		
		
		holder.tvNumber.setText(mList.get(position).getNumber()+"");
		switch (mList.get(position).getMode()+1) {
		case 1:
			holder.tvMode.setText("�绰����");
			break;
		case 2:
			holder.tvMode.setText("��������");
			break;
		case 3:
			holder.tvMode.setText("�绰����������");
			break;

		default:
			break;
		}
		
		holder.vDelete.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				mDao = BlackNumberDao.getInstance(mContext);
				
				int count = mDao.delete(mList.get(position).getNumber());
				//System.out.println("����ɹ���" + "  result:" + count + "  number:" + mList.get(position).getNumber());
				if (count > 0) {   //ɾ���ɹ�
					System.out.println("���ݿ�ɾ���ɹ���");
					
					mList.remove(position);    //����ɾ��item
					System.out.println("ҳ������ɾ���ɹ���");
					
					BlackNumberAdapter.this.notifyDataSetChanged();   //���½���
					System.out.println("ҳ��ˢ�³ɹ���");
				}
			}
		});
		
		return convertView;
	}
	
	static class ViewHolder{
		public TextView tvNumber;
		public TextView tvMode;
		public View vDelete;
	}

}
