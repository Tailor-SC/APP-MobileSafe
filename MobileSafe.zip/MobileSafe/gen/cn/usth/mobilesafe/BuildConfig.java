/** Automatically generated file. DO NOT MODIFY */
package cn.usth.mobilesafe;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}